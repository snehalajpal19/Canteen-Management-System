import os
from datetime import datetime
from decimal import Decimal, InvalidOperation
from contextlib import contextmanager

import psycopg2
from psycopg2.extras import RealDictCursor
from flask import Flask, flash, redirect, render_template, request, url_for
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "development-only-change-me")


@contextmanager
def get_db():
    """Yield a short-lived PostgreSQL connection and always close it."""
    conn = psycopg2.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=os.getenv("DB_PORT", "5432"),
        dbname=os.getenv("DB_NAME", "campus_canteen"),
        user=os.getenv("DB_USER", "postgres"),
        password=os.getenv("DB_PASSWORD", ""),
        cursor_factory=RealDictCursor,
        connect_timeout=4,
    )
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def safe_int(value, label, minimum=1):
    try:
        number = int(value)
    except (TypeError, ValueError):
        raise ValueError(f"{label} must be a whole number.")
    if number < minimum:
        raise ValueError(f"{label} must be at least {minimum}.")
    return number


def safe_price(value):
    try:
        price = Decimal(value).quantize(Decimal("0.01"))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("Enter a valid price, e.g. 35.00.")
    if price <= 0:
        raise ValueError("Price must be greater than zero.")
    return price


def friendly_db_error(exc):
    message = str(exc).lower()
    if "duplicate key" in message or "unique constraint" in message:
        return "That name, roll number, email, or order number already exists. Use a unique value."
    if "foreign key constraint" in message or "violates foreign key" in message:
        return "This record is linked to order history, so it cannot be deleted. Keep the history intact."
    if "check constraint" in message:
        return "One of the values is outside the allowed range. Check the form and try again."
    return "The database rejected this operation. Check required fields and linked records, then try again."


def rows_or_empty(query, params=()):
    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
            return cur.fetchall()


@app.route("/")
def index():
    try:
        stats = rows_or_empty("""
            SELECT
              (SELECT COUNT(*) FROM students) AS student_count,
              (SELECT COUNT(*) FROM menu_items WHERE is_available = TRUE) AS available_items,
              (SELECT COUNT(*) FROM orders) AS order_count,
              (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE order_status <> 'Cancelled') AS sales_total
        """)[0]
        recent_orders = rows_or_empty("""
            SELECT o.order_number, s.full_name, o.order_status, o.order_date, o.total_amount
            FROM orders o JOIN students s ON s.student_id = o.student_id
            ORDER BY o.order_date DESC, o.order_id DESC LIMIT 7
        """)
        return render_template("index.html", stats=stats, recent_orders=recent_orders)
    except psycopg2.Error:
        flash("Could not connect to PostgreSQL. Check .env and confirm the schema/sample data were loaded.", "error")
        return render_template("index.html", stats=None, recent_orders=[])


@app.route("/menu", methods=["GET", "POST"])
def menu():
    if request.method == "POST":
        try:
            name = request.form.get("item_name", "").strip()
            category = request.form.get("category", "").strip()
            price = safe_price(request.form.get("price", ""))
            prep_time = safe_int(request.form.get("prep_time_mins", "10"), "Preparation time")
            if not name or not category:
                raise ValueError("Item name and category are required.")
            if prep_time > 120:
                raise ValueError("Preparation time cannot exceed 120 minutes.")
            with get_db() as conn:
                with conn.cursor() as cur:
                    cur.execute("INSERT INTO menu_items (item_name, category, price, prep_time_mins) VALUES (%s, %s, %s, %s)", (name, category, price, prep_time))
            flash(f"{name} added to the menu.", "success")
        except ValueError as exc:
            flash(str(exc), "error")
        except psycopg2.Error as exc:
            flash(friendly_db_error(exc), "error")
        return redirect(url_for("menu"))

    q = request.args.get("q", "").strip()
    try:
        items = rows_or_empty("""
            SELECT item_id, item_name, category, price, is_available, prep_time_mins
            FROM menu_items
            WHERE item_name ILIKE %s OR category ILIKE %s
            ORDER BY item_name
        """, (f"%{q}%", f"%{q}%"))
    except psycopg2.Error:
        items = []
    return render_template("menu.html", items=items, q=q)


@app.post("/menu/<int:item_id>/update")
def update_menu(item_id):
    try:
        name = request.form.get("item_name", "").strip()
        category = request.form.get("category", "").strip()
        price = safe_price(request.form.get("price", ""))
        prep_time = safe_int(request.form.get("prep_time_mins", "10"), "Preparation time")
        is_available = request.form.get("is_available") == "true"
        if not name or not category:
            raise ValueError("Item name and category are required.")
        if prep_time > 120:
            raise ValueError("Preparation time cannot exceed 120 minutes.")
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("UPDATE menu_items SET item_name=%s, category=%s, price=%s, prep_time_mins=%s, is_available=%s WHERE item_id=%s", (name, category, price, prep_time, is_available, item_id))
                if cur.rowcount == 0:
                    flash("Menu item not found.", "error")
                else:
                    flash("Menu item updated.", "success")
    except ValueError as exc:
        flash(str(exc), "error")
    except psycopg2.Error as exc:
        flash(friendly_db_error(exc), "error")
    return redirect(url_for("menu"))


@app.post("/menu/<int:item_id>/delete")
def delete_menu(item_id):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM menu_items WHERE item_id=%s", (item_id,))
                if cur.rowcount:
                    flash("Menu item deleted.", "success")
                else:
                    flash("Menu item not found.", "error")
    except psycopg2.Error as exc:
        flash(friendly_db_error(exc), "error")
    return redirect(url_for("menu"))


@app.route("/students", methods=["GET", "POST"])
def students():
    if request.method == "POST":
        try:
            name = request.form.get("full_name", "").strip()
            roll = request.form.get("roll_number", "").strip()
            email = request.form.get("email", "").strip().lower()
            department = request.form.get("department", "CSE").strip()
            year = safe_int(request.form.get("study_year", "1"), "Study year")
            if not name or not roll or not email or not department:
                raise ValueError("All student fields are required.")
            if "@" not in email or "." not in email.rsplit("@", 1)[-1]:
                raise ValueError("Enter a valid email address.")
            if year > 4:
                raise ValueError("Study year must be between 1 and 4.")
            with get_db() as conn:
                with conn.cursor() as cur:
                    cur.execute("INSERT INTO students (full_name, roll_number, email, department, study_year) VALUES (%s, %s, %s, %s, %s)", (name, roll, email, department, year))
            flash(f"Student {name} added.", "success")
        except ValueError as exc:
            flash(str(exc), "error")
        except psycopg2.Error as exc:
            flash(friendly_db_error(exc), "error")
        return redirect(url_for("students"))

    q = request.args.get("q", "").strip()
    try:
        student_rows = rows_or_empty("""
            SELECT student_id, full_name, roll_number, email, department, study_year
            FROM students
            WHERE full_name ILIKE %s OR roll_number ILIKE %s OR email ILIKE %s
            ORDER BY full_name
        """, (f"%{q}%", f"%{q}%", f"%{q}%"))
    except psycopg2.Error:
        student_rows = []
    return render_template("students.html", students=student_rows, q=q)


@app.post("/students/<int:student_id>/update")
def update_student(student_id):
    try:
        name = request.form.get("full_name", "").strip()
        roll = request.form.get("roll_number", "").strip()
        email = request.form.get("email", "").strip().lower()
        department = request.form.get("department", "CSE").strip()
        year = safe_int(request.form.get("study_year", "1"), "Study year")
        if not all([name, roll, email, department]):
            raise ValueError("All student fields are required.")
        if "@" not in email or "." not in email.rsplit("@", 1)[-1]:
            raise ValueError("Enter a valid email address.")
        if year > 4:
            raise ValueError("Study year must be between 1 and 4.")
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("UPDATE students SET full_name=%s, roll_number=%s, email=%s, department=%s, study_year=%s WHERE student_id=%s", (name, roll, email, department, year, student_id))
                flash("Student updated." if cur.rowcount else "Student not found.", "success" if cur.rowcount else "error")
    except ValueError as exc:
        flash(str(exc), "error")
    except psycopg2.Error as exc:
        flash(friendly_db_error(exc), "error")
    return redirect(url_for("students"))


@app.post("/students/<int:student_id>/delete")
def delete_student(student_id):
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM students WHERE student_id=%s", (student_id,))
                flash("Student deleted." if cur.rowcount else "Student not found.", "success" if cur.rowcount else "error")
    except psycopg2.Error as exc:
        flash(friendly_db_error(exc), "error")
    return redirect(url_for("students"))


@app.route("/orders", methods=["GET", "POST"])
def orders():
    if request.method == "POST":
        try:
            student_id = safe_int(request.form.get("student_id"), "Student")
            item_id = safe_int(request.form.get("item_id"), "Menu item")
            quantity = safe_int(request.form.get("quantity"), "Quantity")
            if quantity > 50:
                raise ValueError("Quantity cannot exceed 50 in one order line.")
            with get_db() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT student_id FROM students WHERE student_id=%s", (student_id,))
                    if not cur.fetchone():
                        raise ValueError("Select a valid student.")
                    cur.execute("SELECT item_name, price FROM menu_items WHERE item_id=%s AND is_available=TRUE", (item_id,))
                    item = cur.fetchone()
                    if not item:
                        raise ValueError("Select an available menu item.")
                    total = (Decimal(item["price"]) * quantity).quantize(Decimal("0.01"))
                    order_number = "CC-" + datetime.now().strftime("%y%m%d%H%M%S%f")[-12:]
                    cur.execute("INSERT INTO orders (order_number, student_id, order_status, total_amount) VALUES (%s, %s, 'Placed', %s) RETURNING order_id", (order_number, student_id, total))
                    order_id = cur.fetchone()["order_id"]
                    cur.execute("INSERT INTO order_items (order_id, item_id, quantity, unit_price) VALUES (%s, %s, %s, %s)", (order_id, item_id, quantity, item["price"]))
            flash(f"Order {order_number} placed for ₹{total}.", "success")
        except ValueError as exc:
            flash(str(exc), "error")
        except psycopg2.Error as exc:
            flash(friendly_db_error(exc), "error")
        return redirect(url_for("orders"))

    q = request.args.get("q", "").strip()
    try:
        students_list = rows_or_empty("SELECT student_id, full_name, roll_number FROM students ORDER BY full_name")
        menu_list = rows_or_empty("SELECT item_id, item_name, price FROM menu_items WHERE is_available=TRUE ORDER BY item_name")
        order_rows = rows_or_empty("""
            SELECT o.order_id, o.order_number, s.full_name, o.order_date, o.order_status, o.total_amount,
                   COALESCE(string_agg(m.item_name || ' x' || oi.quantity::text, ', ' ORDER BY m.item_name), '') AS items
            FROM orders o
            JOIN students s ON s.student_id=o.student_id
            LEFT JOIN order_items oi ON oi.order_id=o.order_id
            LEFT JOIN menu_items m ON m.item_id=oi.item_id
            WHERE o.order_number ILIKE %s OR s.full_name ILIKE %s OR o.order_status ILIKE %s
            GROUP BY o.order_id, s.full_name
            ORDER BY o.order_date DESC, o.order_id DESC
            LIMIT 100
        """, (f"%{q}%", f"%{q}%", f"%{q}%"))
    except psycopg2.Error:
        students_list, menu_list, order_rows = [], [], []
    return render_template("orders.html", students=students_list, menu_items=menu_list, orders=order_rows, q=q)


@app.post("/orders/<int:order_id>/status")
def update_order_status(order_id):
    status = request.form.get("order_status", "")
    allowed = {"Placed", "Preparing", "Ready", "Completed", "Cancelled"}
    if status not in allowed:
        flash("Choose a valid order status.", "error")
        return redirect(url_for("orders"))
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("UPDATE orders SET order_status=%s WHERE order_id=%s", (status, order_id))
                flash("Order status updated." if cur.rowcount else "Order not found.", "success" if cur.rowcount else "error")
    except psycopg2.Error as exc:
        flash(friendly_db_error(exc), "error")
    return redirect(url_for("orders"))


@app.route("/reports")
def reports():
    try:
        top_items = rows_or_empty("""
            SELECT m.item_name, m.category, SUM(oi.quantity) AS units_sold,
                   SUM(oi.line_total) AS item_revenue
            FROM menu_items m
            JOIN order_items oi ON oi.item_id=m.item_id
            JOIN orders o ON o.order_id=oi.order_id
            WHERE o.order_status <> 'Cancelled'
            GROUP BY m.item_id, m.item_name, m.category
            HAVING SUM(oi.quantity) > 0
            ORDER BY units_sold DESC, item_revenue DESC, m.item_name
            LIMIT 10
        """)
        student_spend = rows_or_empty("""
            SELECT s.full_name, s.roll_number, COUNT(o.order_id) FILTER (WHERE o.order_status <> 'Cancelled') AS order_count,
                   COALESCE(SUM(o.total_amount) FILTER (WHERE o.order_status <> 'Cancelled'), 0) AS amount_spent
            FROM students s
            LEFT JOIN orders o ON o.student_id=s.student_id
            GROUP BY s.student_id, s.full_name, s.roll_number
            ORDER BY amount_spent DESC, s.full_name
        """)
        summary = rows_or_empty("""
            SELECT COUNT(*) FILTER (WHERE order_status <> 'Cancelled') AS valid_orders,
                   COALESCE(SUM(total_amount) FILTER (WHERE order_status <> 'Cancelled'), 0) AS gross_sales,
                   COALESCE(ROUND(AVG(total_amount) FILTER (WHERE order_status <> 'Cancelled'), 2), 0) AS avg_order
            FROM orders
        """)[0]
    except psycopg2.Error:
        top_items, student_spend = [], []
        summary = {"valid_orders": 0, "gross_sales": 0, "avg_order": 0}
    return render_template("reports.html", top_items=top_items, student_spend=student_spend, summary=summary)


@app.route("/health")
def health():
    try:
        rows_or_empty("SELECT 1")
        return {"status": "ok", "database": os.getenv("DB_NAME", "campus_canteen")}
    except psycopg2.Error as exc:
        return {"status": "database_error", "message": str(exc)}, 503


if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
