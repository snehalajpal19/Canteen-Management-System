from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Image, Table, TableStyle, KeepTogether
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
import os

BASE = '/mnt/data/Campus_Canteen_DBMS_Project'
OUT = os.path.join(BASE, 'docs', 'Campus_Canteen_DBMS_Report.pdf')
FONT_REG = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONT_BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
pdfmetrics.registerFont(TTFont('DejaVu', FONT_REG))
pdfmetrics.registerFont(TTFont('DejaVu-Bold', FONT_BOLD))

NAVY = colors.HexColor('#253344')
ORANGE = colors.HexColor('#ED743E')
GREEN = colors.HexColor('#299875')
INK = colors.HexColor('#28313c')
MUTED = colors.HexColor('#6f7b88')
PALE = colors.HexColor('#FBF7F2')
LINE = colors.HexColor('#e3e6e8')
WHITE = colors.white

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name='CoverKicker', fontName='DejaVu-Bold', fontSize=9, leading=13, textColor=ORANGE, alignment=TA_CENTER, spaceAfter=15, tracking=1.5))
styles.add(ParagraphStyle(name='CoverTitle', fontName='DejaVu-Bold', fontSize=29, leading=35, textColor=NAVY, alignment=TA_CENTER, spaceAfter=13))
styles.add(ParagraphStyle(name='CoverSub', fontName='DejaVu', fontSize=12, leading=18, textColor=MUTED, alignment=TA_CENTER, spaceAfter=18))
styles.add(ParagraphStyle(name='H1x', fontName='DejaVu-Bold', fontSize=17, leading=22, textColor=NAVY, spaceBefore=2, spaceAfter=10))
styles.add(ParagraphStyle(name='H2x', fontName='DejaVu-Bold', fontSize=11, leading=15, textColor=ORANGE, spaceBefore=8, spaceAfter=5))
styles.add(ParagraphStyle(name='Bodyx', fontName='DejaVu', fontSize=8.5, leading=13, textColor=INK, spaceAfter=6))
styles.add(ParagraphStyle(name='Smallx', fontName='DejaVu', fontSize=7.3, leading=10, textColor=MUTED, spaceAfter=4))
styles.add(ParagraphStyle(name='Bulletx', fontName='DejaVu', fontSize=8.4, leading=12.5, textColor=INK, leftIndent=12, firstLineIndent=-8, bulletIndent=0, spaceAfter=4))
styles.add(ParagraphStyle(name='Calloutx', fontName='DejaVu-Bold', fontSize=9, leading=13, textColor=NAVY, spaceAfter=4))
styles.add(ParagraphStyle(name='Cellx', fontName='DejaVu', fontSize=7.0, leading=9, textColor=INK))
styles.add(ParagraphStyle(name='CellBoldx', fontName='DejaVu-Bold', fontSize=7.0, leading=9, textColor=WHITE))
styles.add(ParagraphStyle(name='Captionx', fontName='DejaVu', fontSize=7.4, leading=10, textColor=MUTED, alignment=TA_CENTER))


def P(text, style='Bodyx'):
    return Paragraph(text, styles[style])

def bullet(text):
    return Paragraph('• ' + text, styles['Bulletx'])

def table(rows, widths, header=True, font=7.0):
    cooked = []
    for ri, row in enumerate(rows):
        cooked.append([c if isinstance(c, Paragraph) else Paragraph(str(c), styles['CellBoldx'] if header and ri == 0 else styles['Cellx']) for c in row])
    t = Table(cooked, colWidths=widths, repeatRows=1 if header else 0, hAlign='LEFT')
    commands = [
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 6), ('RIGHTPADDING', (0,0), (-1,-1), 6),
        ('TOPPADDING', (0,0), (-1,-1), 5), ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('GRID', (0,0), (-1,-1), 0.35, LINE),
    ]
    if header:
        commands += [('BACKGROUND', (0,0), (-1,0), NAVY), ('TEXTCOLOR', (0,0), (-1,0), WHITE)]
        if len(rows) > 1:
            commands += [('ROWBACKGROUNDS', (0,1), (-1,-1), [WHITE, PALE])]
    else:
        commands += [('ROWBACKGROUNDS', (0,0), (-1,-1), [WHITE, PALE])]
    t.setStyle(TableStyle(commands))
    return t


def footer(canvas, doc):
    canvas.saveState()
    page = canvas.getPageNumber()
    if page > 1:
        w, h = A4
        canvas.setStrokeColor(LINE)
        canvas.setLineWidth(0.5)
        canvas.line(18*mm, 14*mm, w-18*mm, 14*mm)
        canvas.setFont('DejaVu', 7)
        canvas.setFillColor(MUTED)
        canvas.drawString(18*mm, 9*mm, 'CAMPUS CANTEEN MANAGEMENT SYSTEM  |  DBMS MICRO PROJECT')
        canvas.drawRightString(w-18*mm, 9*mm, f'{page}')
    canvas.restoreState()

story = []
# Cover page
story += [Spacer(1, 25*mm), P('DATABASE MANAGEMENT SYSTEMS • MICRO PROJECT', 'CoverKicker'),
          P('Campus Canteen<br/>Management System', 'CoverTitle'),
          P('A compact, database-driven web prototype for student records, menu management, orders and sales reporting.', 'CoverSub'),
          Spacer(1, 5*mm)]
cover_box = Table([
    [P('<b>DATABASE</b><br/>PostgreSQL', 'Bodyx'), P('<b>BACKEND</b><br/>Python Flask', 'Bodyx'), P('<b>INTERFACE</b><br/>HTML + CSS', 'Bodyx')],
], colWidths=[48*mm,48*mm,48*mm], rowHeights=[23*mm], hAlign='CENTER')
cover_box.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),PALE),('BOX',(0,0),(-1,-1),0.8,LINE),('INNERGRID',(0,0),(-1,-1),0.6,LINE),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),8)]))
story += [cover_box, Spacer(1, 22*mm)]
meta = Table([
    [P('<b>Student name(s)</b>', 'Bodyx'), P('____________________________________________________', 'Bodyx')],
    [P('<b>Class / Division</b>', 'Bodyx'), P('____________________________________________________', 'Bodyx')],
    [P('<b>Roll number(s)</b>', 'Bodyx'), P('____________________________________________________', 'Bodyx')],
    [P('<b>Faculty</b>', 'Bodyx'), P('____________________________________________________', 'Bodyx')],
], colWidths=[42*mm,112*mm])
meta.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,-1),0.35,LINE)]))
story += [meta, Spacer(1, 20*mm), P('PROJECT REPORT • 2026', 'CoverKicker'), PageBreak()]

# Page 2 problem statement
story += [P('1. Project overview', 'H1x'),
          P('<b>Title:</b> Campus Canteen Management System', 'Bodyx'),
          P('<b>Background:</b> A college canteen handles student orders throughout the day. When details are recorded informally, staff may find it difficult to maintain menu prices, retrieve student details, track order progress, and summarize sales.', 'Bodyx'),
          P('<b>Existing problem / limitation:</b> Manual registers or disconnected spreadsheets can lead to duplicate records, slow searching, inconsistent prices, and time-consuming report preparation. They also do not automatically enforce relationships between students, orders and menu items.', 'Bodyx'),
          P('<b>Proposed database solution:</b> A PostgreSQL database stores student details, menu items, order headers and order-item details in related tables. A Flask web interface provides data entry, update, delete, search, order tracking and summary reports.', 'Bodyx'),
          P('Objectives', 'H2x'),
          bullet('Design a valid ER model with entities, attributes, keys, cardinality and participation constraints.'),
          bullet('Map the ER model to relations with primary keys, alternate keys, foreign keys, data types and checks.'),
          bullet('Demonstrate DDL, DML, joins, filtering, sorting, aggregates, GROUP BY, HAVING and a nested query.'),
          bullet('Build a working frontend that interacts with PostgreSQL and demonstrates the main use cases.'),
          P('Scope and users', 'H2x'),
          P('The intended users are canteen staff who maintain the menu and student directory, record orders, update preparation status, and review simple business summaries. This is an educational prototype: it does not collect payment card data or implement a live payment gateway.', 'Bodyx'),
          P('Technology stack', 'H2x'),
          table([['Layer','Technology','Purpose'],['Database','PostgreSQL','Store related records and enforce integrity constraints'],['Backend','Python + Flask','Handle forms, validate input and run parameterized SQL'],['Frontend','HTML + CSS + small JavaScript','Provide dashboard, CRUD screens, order entry and reports'],['DB client','pgAdmin 4','Create database, run schema and inspect query results']], [29*mm,45*mm,91*mm]),
          PageBreak()]

# Page 3 ER model
story += [P('2. ER diagram and relationship design', 'H1x'),
          P('The system has four entities. STUDENTS and MENU_ITEMS are master entities; ORDERS and ORDER_ITEMS capture transactions. ORDER_ITEMS resolves the many-to-many relationship between orders and menu items.', 'Bodyx')]
er_img = Image(os.path.join(BASE, 'docs', 'ER_Diagram.png'), width=120*mm, height=113*mm, kind='proportional', hAlign='CENTER')
story += [er_img, Spacer(1, 3*mm), P('Figure 1. ER model. PK = primary key; FK = foreign key; AK = alternate/candidate key. The labels show the intended cardinalities.', 'Captionx'), Spacer(1, 3*mm),
          P('Relationships and cardinality', 'H2x'),
          table([['Relationship','Cardinality','Participation constraint / explanation'],
                 ['Student — Order','1 : 0..N','A student may have no orders or many orders (partial participation on Student). Each Order must reference exactly one Student (total participation on Order, implemented through NOT NULL FK).'],
                 ['Order — Order Item','1 : 1..N','An order is conceptually made up of one or more order lines. Each Order Item must reference one Order (total participation on Order Item). The simple FK enforces parent existence; minimum one line is a transaction/business rule.'],
                 ['Menu Item — Order Item','1 : 0..N','A menu item may never be ordered or may appear in many order lines (partial participation on Menu Item). Each Order Item refers to exactly one menu item (total participation on Order Item).']], [39*mm,27*mm,99*mm]),
          P('Design note', 'H2x'),
          P('The menu price is copied to ORDER_ITEMS.unit_price at order time. Therefore, changing the current menu price does not rewrite the price charged in an earlier sample order. The generated line_total equals quantity × unit_price.', 'Bodyx'),
          PageBreak()]

# Page 4 relational model master tables
story += [P('3. ER model to relational model — master tables', 'H1x'),
          P('The schema uses integer identity columns as primary keys, NOT NULL and UNIQUE constraints for alternate keys, and CHECK constraints for valid values.', 'Bodyx'),
          P('Relation 1: STUDENTS', 'H2x'),
          table([['Attribute','Data type','Key / constraint'],
                 ['student_id','INTEGER','PK; identity'],
                 ['full_name','VARCHAR(100)','NOT NULL'],
                 ['roll_number','VARCHAR(20)','NOT NULL, UNIQUE (alternate key)'],
                 ['email','VARCHAR(120)','NOT NULL, UNIQUE (alternate key)'],
                 ['department','VARCHAR(60)','NOT NULL; default CSE'],
                 ['study_year','SMALLINT','NOT NULL; CHECK 1–4'],
                 ['created_at','TIMESTAMP','NOT NULL; default current timestamp']], [37*mm,43*mm,85*mm]),
          Spacer(1, 5*mm), P('Relation 2: MENU_ITEMS', 'H2x'),
          table([['Attribute','Data type','Key / constraint'],
                 ['item_id','INTEGER','PK; identity'],
                 ['item_name','VARCHAR(80)','NOT NULL, UNIQUE (alternate key)'],
                 ['category','VARCHAR(40)','NOT NULL'],
                 ['price','NUMERIC(8,2)','NOT NULL; CHECK price > 0'],
                 ['is_available','BOOLEAN','NOT NULL; default TRUE'],
                 ['created_at','TIMESTAMP','NOT NULL; default current timestamp'],
                 ['prep_time_mins','INTEGER','Added through ALTER TABLE; CHECK 1–120']], [37*mm,43*mm,85*mm]),
          P('Candidate / alternate keys', 'H2x'),
          P('A candidate key uniquely identifies a row. In STUDENTS, student_id is the chosen primary key; roll_number and email are alternate candidate keys. In MENU_ITEMS, item_id is the primary key and item_name is an alternate candidate key. The schema uses UNIQUE + NOT NULL to enforce them.', 'Bodyx'),
          PageBreak()]

# Page 5 transaction tables
story += [P('4. Relational model — transaction tables', 'H1x'),
          P('Relation 3: ORDERS', 'H2x'),
          table([['Attribute','Data type','Key / constraint'],
                 ['order_id','INTEGER','PK; identity'],
                 ['order_number','VARCHAR(20)','NOT NULL, UNIQUE (alternate key)'],
                 ['student_id','INTEGER','FK → students.student_id; NOT NULL; ON DELETE RESTRICT'],
                 ['order_status','VARCHAR(20)','CHECK in Placed, Preparing, Ready, Completed, Cancelled'],
                 ['order_date','TIMESTAMP','NOT NULL; default current timestamp'],
                 ['total_amount','NUMERIC(10,2)','NOT NULL; CHECK total_amount ≥ 0']], [37*mm,43*mm,85*mm]),
          Spacer(1, 5*mm), P('Relation 4: ORDER_ITEMS', 'H2x'),
          table([['Attribute','Data type','Key / constraint'],
                 ['order_item_id','INTEGER','PK; identity'],
                 ['order_id','INTEGER','FK → orders.order_id; NOT NULL; ON DELETE CASCADE'],
                 ['item_id','INTEGER','FK → menu_items.item_id; NOT NULL; ON DELETE RESTRICT'],
                 ['quantity','INTEGER','NOT NULL; CHECK quantity > 0'],
                 ['unit_price','NUMERIC(8,2)','NOT NULL; CHECK unit_price > 0'],
                 ['line_total','NUMERIC(10,2)','Generated column: quantity × unit_price'],
                 ['(order_id, item_id)','Composite UNIQUE','Prevents duplicate rows for the same item in one order']], [37*mm,43*mm,85*mm]),
          P('Referential integrity', 'H2x'),
          bullet('An order cannot refer to a nonexistent student because student_id is a foreign key.'),
          bullet('An order item cannot refer to a nonexistent order or menu item.'),
          bullet('Deleting a student with order history and deleting an item used in order history are restricted, protecting historical references.'),
          bullet('Deleting an order removes its order-item rows through ON DELETE CASCADE.'),
          P('Indexes', 'H2x'),
          P('Indexes are created for orders.student_id, orders.order_date and order_items.item_id to support common joins, date-based listing and item reports.', 'Bodyx'),
          PageBreak()]

# Page 6 implementation and queries
story += [P('5. Database implementation', 'H1x'),
          P('The implementation files are provided in the project folder under sql/. Run them in sequence after opening pgAdmin Query Tool.', 'Bodyx'),
          table([['File','What it does'],
                 ['00_create_database.sql','Creates the campus_canteen database while connected to postgres.'],
                 ['01_schema.sql','Creates four relations, adds prep_time_mins with ALTER TABLE, and creates indexes/constraints.'],
                 ['02_sample_data.sql','Loads 8 students, 10 menu items, 12 orders and 22 order-item records.'],
                 ['03_demo_queries.sql','Contains runnable SELECT, WHERE, ORDER BY, aggregate, JOIN, GROUP BY, HAVING and nested-query examples; includes commented UPDATE/DELETE examples.']], [51*mm,114*mm]),
          P('Required SQL operations demonstrated', 'H2x'),
          bullet('<b>DDL:</b> CREATE DATABASE, CREATE TABLE, ALTER TABLE, primary keys, foreign keys, UNIQUE, CHECK, NOT NULL and indexes.'),
          bullet('<b>DML:</b> INSERT through sample data and frontend forms; UPDATE through edit forms and order-status controls; DELETE through master-record management.'),
          bullet('<b>Query operations:</b> SELECT, WHERE, ORDER BY, COUNT, SUM, AVG, GROUP BY, HAVING, INNER JOIN, LEFT JOIN and a nested query.'),
          P('Example report query pattern', 'H2x'),
          P('The popular-item report joins MENU_ITEMS to ORDER_ITEMS and ORDERS, excludes cancelled orders, groups rows by menu item, calculates SUM(quantity) and SUM(line_total), then sorts by units sold. The student-spend report uses a LEFT JOIN so a student with no orders can still appear with zero spend.', 'Bodyx'),
          P('Sample-data sizing check', 'H2x'),
          table([['Table','Supplied sample records','Guideline check'],['students','8','Within recommended 5–10 master records'],['menu_items','10','Within recommended 5–10 master records'],['orders','12','Meets 10–15 transaction-row guidance'],['order_items','22','Exceeds 10–15 transaction detail rows']], [45*mm,47*mm,73*mm]),
          P('All values in the sample records are fictional and intended only for classroom demonstration.', 'Smallx'),
          PageBreak()]

# Page 7 frontend & testing
story += [P('6. Frontend prototype, testing and conclusion', 'H1x'),
          P('The Flask application is connected to PostgreSQL and exposes the following screens, matching the minimum frontend functions in the project guidelines.', 'Bodyx'),
          table([['Screen','Included functionality','DBMS concepts visible'],
                 ['Home / Dashboard','Shows student count, available menu items, order count, order value and recent orders.','COUNT, SUM, JOIN, ORDER BY'],
                 ['Menu items','Add, search, edit price/category/availability, delete when not referenced.','INSERT, SELECT, WHERE/ILIKE, UPDATE, DELETE, constraints'],
                 ['Students','Add, search by name/roll/email, update and delete where allowed.','UNIQUE alternate keys, WHERE, CRUD'],
                 ['Orders','Place an order, search history, update status.','Transaction insert, PK/FK relationships, JOIN, aggregate price calculation'],
                 ['Reports','Popular menu items and spending by student.','INNER/LEFT JOIN, GROUP BY, HAVING, SUM, COUNT, COALESCE']], [33*mm,74*mm,58*mm]),
          P('Demonstration and test checklist', 'H2x'),
          bullet('Connect to the campus_canteen database; open the dashboard and explain the four tables.'),
          bullet('Add a menu item, search it, update the price and delete it if it has no order history.'),
          bullet('Add or update a student. Try a duplicate email or roll number to demonstrate a UNIQUE constraint.'),
          bullet('Place an order, update its status, then show the new row and related order-item data in pgAdmin.'),
          bullet('Open Reports and explain how joins and aggregate queries produce the totals.'),
          bullet('Run selected examples from sql/03_demo_queries.sql, especially the JOIN, HAVING and nested-query examples.'),
          P('Conclusion', 'H2x'),
          P('The Campus Canteen Management System demonstrates the complete DBMS micro-project workflow: problem definition, ER design, relational mapping, PostgreSQL implementation, sample data, SQL operations and frontend–database integration. The project is intentionally small enough to explain clearly in a viva while still showing meaningful integrity constraints and useful reports.', 'Bodyx'),
          Spacer(1, 3*mm),
          Table([[P('<b>Project run command</b>', 'Calloutx'), P('python app.py', 'Bodyx')], [P('<b>Local website</b>', 'Calloutx'), P('http://127.0.0.1:5000', 'Bodyx')]], colWidths=[42*mm, 123*mm], style=TableStyle([('BACKGROUND',(0,0),(0,-1),PALE),('BOX',(0,0),(-1,-1),0.5,LINE),('INNERGRID',(0,0),(-1,-1),0.35,LINE),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))]

doc = SimpleDocTemplate(OUT, pagesize=A4, rightMargin=18*mm, leftMargin=18*mm, topMargin=17*mm, bottomMargin=19*mm, title='Campus Canteen Management System - DBMS Micro Project', author='DBMS Micro Project')
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print(OUT)
