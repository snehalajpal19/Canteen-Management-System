# Campus Canteen Management System (DBMS Micro Project)

A small campus canteen application built with **PostgreSQL + Python Flask + HTML/CSS**. It manages students, menu items, orders, and order line items, and produces simple sales reports.

## Why this idea?
- Familiar real-world problem; easy to explain in a viva.
- Four related tables are enough to demonstrate ER modelling, PK/FK constraints, and one-to-many relationships.
- The interface includes a dashboard, insert/update/delete/search for master records, order entry, and two reports.
- Includes sample data and SQL examples for `SELECT`, `WHERE`, `ORDER BY`, aggregates, `GROUP BY`, `HAVING`, joins, a nested query, `INSERT`, `UPDATE`, `DELETE`, and `ALTER TABLE`.

## Requirements
- Python 3.10+
- PostgreSQL (pgAdmin 4 is fine)
- A modern browser

## Setup

### 1) Create the database
Connect pgAdmin Query Tool to your default `postgres` database and execute `sql/00_create_database.sql` once. It creates `campus_canteen`.

### 2) Create the schema and sample data
In pgAdmin, connect to the new `campus_canteen` database. Open and execute, in this order:
1. `sql/01_schema.sql`
2. `sql/02_sample_data.sql`

The sample script adds 8 students, 10 menu items, 12 orders, and 22 order-item rows. If `campus_canteen` already exists, skip step 1. The schema intentionally avoids destructive `DROP TABLE` statements.

### 3) Configure the app
From this project folder, make a copy of `.env.example` named `.env`. Set `DB_PASSWORD` to your local PostgreSQL password. Keep `DB_NAME=campus_canteen`.

### 4) Install and run
**Windows (recommended):** double-click `run_windows.bat`. On first launch it creates a virtual environment, installs dependencies, and copies `.env.example` to `.env` if needed. Set `DB_PASSWORD` in `.env` to your PostgreSQL password when prompted, and make sure the SQL setup steps above are completed.

**Windows PowerShell (manual):**
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
Copy-Item .env.example .env   # only if .env does not exist
notepad .env                  # set DB_PASSWORD
py app.py
```

**Ubuntu / macOS:**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # only if .env does not exist
nano .env                     # set DB_PASSWORD
python app.py
```

Open `http://127.0.0.1:5000` in your browser. Keep the terminal open while using the site.

## Pages / required functions
- **Dashboard:** counts for students, available menu items and orders; order value; latest orders.
- **Menu:** add, search, update and delete menu items.
- **Students:** add, search, update and delete student records.
- **Orders:** place an order for a student and item; update order status; search orders.
- **Reports:** top-selling items and spend by student.

## ER model summary
- One **Student** may place zero or many **Orders**; every Order belongs to exactly one Student.
- One **Order** has one or many **Order Items**; every Order Item belongs to exactly one Order.
- One **Menu Item** can appear in zero or many **Order Items**; every Order Item refers to exactly one Menu Item.

`order_items` is the associative/transaction detail entity that resolves the many-to-many relationship between Orders and Menu Items. It also stores the price at the time of purchase so historical orders do not change when menu prices are edited.

## Tables and keys
- `students`: `student_id` PK; `roll_number` and `email` are alternate/candidate keys (UNIQUE + NOT NULL).
- `menu_items`: `item_id` PK; `item_name` is an alternate/candidate key (UNIQUE + NOT NULL).
- `orders`: `order_id` PK; `order_number` alternate/candidate key; `student_id` FK.
- `order_items`: `order_item_id` PK; `order_id` and `item_id` FKs; `(order_id, item_id)` unique to avoid duplicate lines for one menu item.

## Demo checklist
1. Open Dashboard and explain the four tables.
2. Add a menu item, search for it, edit its price, then delete it if it has no order history.
3. Add/search/edit a student.
4. Place an order and change its status.
5. Open Reports and explain the JOIN + GROUP BY calculation.
6. Open `sql/03_demo_queries.sql` and explain one WHERE, JOIN, HAVING and subquery example.

## Notes
- Deleting a student with existing orders or a menu item referenced by order history is blocked by foreign-key constraints intentionally; this preserves referential integrity.
- The order-entry screen creates one order line per submission to keep the demonstration simple. The schema supports multiple order lines for an order.
- This is a classroom prototype, not a production payment system. No real payment details are collected.
