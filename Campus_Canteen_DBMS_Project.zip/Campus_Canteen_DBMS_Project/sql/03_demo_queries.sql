-- DBMS Micro Project: query examples for viva / demonstration.

-- 1. SELECT + WHERE + ORDER BY: show available menu items, low to high price.
SELECT item_name, category, price
FROM menu_items
WHERE is_available = TRUE
ORDER BY price ASC;

-- 2. Aggregate functions: overall order count, average bill, and total sales.
SELECT COUNT(*) AS total_orders,
       ROUND(AVG(total_amount), 2) AS average_bill,
       SUM(total_amount) AS total_order_value
FROM orders
WHERE order_status <> 'Cancelled';

-- 3. JOIN: display order number, student, and order value.
SELECT o.order_number, s.full_name, o.order_date, o.order_status, o.total_amount
FROM orders o
INNER JOIN students s ON s.student_id = o.student_id
ORDER BY o.order_date DESC;

-- 4. GROUP BY + HAVING: item quantities where at least two units were sold.
SELECT m.item_name, SUM(oi.quantity) AS units_sold
FROM menu_items m
JOIN order_items oi ON oi.item_id = m.item_id
JOIN orders o ON o.order_id = oi.order_id
WHERE o.order_status <> 'Cancelled'
GROUP BY m.item_id, m.item_name
HAVING SUM(oi.quantity) >= 2
ORDER BY units_sold DESC, m.item_name;

-- 5. Nested query: menu items priced above the average menu price.
SELECT item_name, price
FROM menu_items
WHERE price > (SELECT AVG(price) FROM menu_items)
ORDER BY price DESC;

-- 6. Report: revenue by student.
SELECT s.full_name, COUNT(o.order_id) AS orders_placed,
       COALESCE(SUM(CASE WHEN o.order_status <> 'Cancelled' THEN o.total_amount ELSE 0 END), 0) AS amount_spent
FROM students s
LEFT JOIN orders o ON o.student_id = s.student_id
GROUP BY s.student_id, s.full_name
ORDER BY amount_spent DESC;

-- 7. DML demonstration (uncomment and change target values as needed):
-- UPDATE menu_items SET price = 22.00 WHERE item_id = 1;
-- DELETE FROM menu_items WHERE item_id = 10; -- will be blocked if an order references the item

-- 8. If a schema change is required later, use ALTER TABLE; example:
-- ALTER TABLE menu_items ADD COLUMN supplier_name VARCHAR(80);
