-- Run after 01_schema.sql. Inserts use fixed IDs to make the sample relationships easy to follow.
-- ON CONFLICT makes repeated execution safer for the supplied sample IDs.

INSERT INTO students (student_id, full_name, roll_number, email, department, study_year) VALUES
(1, 'Aarav Sharma', 'CSE2401', 'aarav.sharma@example.edu', 'CSE', 2),
(2, 'Ananya Patil', 'CSE2402', 'ananya.patil@example.edu', 'CSE', 2),
(3, 'Kabir Mehta', 'CSE2403', 'kabir.mehta@example.edu', 'CSE', 3),
(4, 'Diya Nair', 'CSE2404', 'diya.nair@example.edu', 'CSE', 2),
(5, 'Rohan Shah', 'CSE2405', 'rohan.shah@example.edu', 'CSE', 1),
(6, 'Isha Kulkarni', 'CSE2406', 'isha.kulkarni@example.edu', 'CSE', 3),
(7, 'Vivaan Joshi', 'CSE2407', 'vivaan.joshi@example.edu', 'CSE', 4),
(8, 'Sara Fernandes', 'CSE2408', 'sara.fernandes@example.edu', 'CSE', 2)
ON CONFLICT (student_id) DO NOTHING;

INSERT INTO menu_items (item_id, item_name, category, price, is_available, prep_time_mins) VALUES
(1, 'Vada Pav', 'Snacks', 20.00, TRUE, 5),
(2, 'Masala Dosa', 'South Indian', 60.00, TRUE, 12),
(3, 'Veg Sandwich', 'Snacks', 45.00, TRUE, 8),
(4, 'Samosa', 'Snacks', 15.00, TRUE, 4),
(5, 'Cold Coffee', 'Beverages', 50.00, TRUE, 6),
(6, 'Cutting Chai', 'Beverages', 12.00, TRUE, 3),
(7, 'Poha', 'Breakfast', 30.00, TRUE, 7),
(8, 'Paneer Roll', 'Meals', 70.00, TRUE, 10),
(9, 'Idli Sambar', 'South Indian', 40.00, TRUE, 10),
(10, 'Lemon Juice', 'Beverages', 25.00, TRUE, 3)
ON CONFLICT (item_id) DO NOTHING;

INSERT INTO orders (order_id, order_number, student_id, order_status, order_date, total_amount) VALUES
(1, 'CC-26001', 1, 'Completed', '2026-10-01 09:12:00', 52.00),
(2, 'CC-26002', 2, 'Completed', '2026-10-02 10:15:00', 95.00),
(3, 'CC-26003', 3, 'Completed', '2026-10-03 12:10:00', 100.00),
(4, 'CC-26004', 1, 'Completed', '2026-10-04 11:05:00', 30.00),
(5, 'CC-26005', 4, 'Ready',     '2026-10-05 13:20:00', 82.00),
(6, 'CC-26006', 5, 'Completed', '2026-10-06 09:45:00', 55.00),
(7, 'CC-26007', 6, 'Completed', '2026-10-07 14:05:00', 50.00),
(8, 'CC-26008', 7, 'Preparing', '2026-10-08 12:40:00', 80.00),
(9, 'CC-26009', 8, 'Completed', '2026-10-09 10:25:00', 52.00),
(10, 'CC-26010', 3, 'Completed', '2026-10-10 11:50:00', 70.00),
(11, 'CC-26011', 2, 'Placed', '2026-10-11 13:12:00', 120.00),
(12, 'CC-26012', 4, 'Completed', '2026-10-12 09:30:00', 72.00)
ON CONFLICT (order_id) DO NOTHING;

INSERT INTO order_items (order_item_id, order_id, item_id, quantity, unit_price) VALUES
(1, 1, 1, 2, 20.00), (2, 1, 6, 1, 12.00),
(3, 2, 3, 1, 45.00), (4, 2, 5, 1, 50.00),
(5, 3, 2, 1, 60.00), (6, 3, 9, 1, 40.00),
(7, 4, 4, 2, 15.00),
(8, 5, 8, 1, 70.00), (9, 5, 6, 1, 12.00),
(10, 6, 7, 1, 30.00), (11, 6, 10, 1, 25.00),
(12, 7, 5, 1, 50.00),
(13, 8, 2, 1, 60.00), (14, 8, 1, 1, 20.00),
(15, 9, 9, 1, 40.00), (16, 9, 6, 1, 12.00),
(17, 10, 4, 3, 15.00), (18, 10, 10, 1, 25.00),
(19, 11, 8, 1, 70.00), (20, 11, 5, 1, 50.00),
(21, 12, 7, 2, 30.00), (22, 12, 6, 1, 12.00)
ON CONFLICT (order_item_id) DO NOTHING;

-- Synchronize identity counters if fixed IDs were inserted.
SELECT setval(pg_get_serial_sequence('students', 'student_id'), GREATEST((SELECT COALESCE(MAX(student_id), 1) FROM students), 1), true);
SELECT setval(pg_get_serial_sequence('menu_items', 'item_id'), GREATEST((SELECT COALESCE(MAX(item_id), 1) FROM menu_items), 1), true);
SELECT setval(pg_get_serial_sequence('orders', 'order_id'), GREATEST((SELECT COALESCE(MAX(order_id), 1) FROM orders), 1), true);
SELECT setval(pg_get_serial_sequence('order_items', 'order_item_id'), GREATEST((SELECT COALESCE(MAX(order_item_id), 1) FROM order_items), 1), true);
