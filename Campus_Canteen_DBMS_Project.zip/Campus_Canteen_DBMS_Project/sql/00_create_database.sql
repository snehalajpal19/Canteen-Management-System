-- Run this file while connected to the default 'postgres' database.
-- In pgAdmin: open Query Tool on the postgres database and execute this statement.
CREATE DATABASE campus_canteen;
