@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Creating Python virtual environment...
  py -m venv .venv
  if errorlevel 1 goto :error
)
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
if errorlevel 1 goto :error
if not exist .env (
  copy .env.example .env >nul
  echo Created .env from .env.example.
  echo Open .env and set DB_PASSWORD before the next run.
  notepad .env
  pause
)
echo Confirm PostgreSQL is running and SQL files have been executed in pgAdmin.
python app.py
pause
goto :eof
:error
echo Setup failed. Check Python, internet/package access, and the error shown above.
pause
exit /b 1
